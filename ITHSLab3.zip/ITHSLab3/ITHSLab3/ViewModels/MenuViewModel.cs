﻿using ITHSLab3.ViewModels;

namespace ITHSLab3.ViewModels
{
    public class MenuViewModel : ViewModelBase
    {
        public string Title => "QuizForge – Menu";
    }
}
